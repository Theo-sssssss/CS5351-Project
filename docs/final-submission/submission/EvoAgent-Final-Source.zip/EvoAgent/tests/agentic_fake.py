# 测试用模型替身：用确定性响应模拟角色协议，避免单元测试依赖外部模型服务。

import json


# 本组测试的可控替身，用预设响应隔离外部依赖。
class FakeAgenticClient:
    provider = "fake"
    model = "fake-model"

    # 按角色和输入上下文返回确定性 JSON，并记录测试需要核对的调用信息。
    def complete_json(self, role, _system, user, ledger=None, max_tokens=None):
        if ledger:
            ledger.record_model(
                role, self.provider, self.model,
                {"prompt_tokens": 10, "completion_tokens": 5}, 1,
            )
        managed = json.loads(user)
        task = json.loads(managed["task"])
        if role == "lead":
            if task["phase"] == "overview":
                return {"action": "final", "review_focus": ["Review every batch"]}
            if task["phase"] == "delegate":
                skills = [
                    item["name"] for item in task.get("available_agent_skills") or []
                ]
                return {
                    "action": "final",
                    "delegations": [
                        {
                            "assignment_id": "security-1", "worker": "security",
                            "objective": "Review security",
                            "skills": skills,
                        },
                        {
                            "assignment_id": "reliability-1",
                            "worker": "correctness-reliability",
                            "objective": "Review correctness and reliability",
                            "skills": skills,
                        },
                    ], "risk_level": "normal",
                }
            if task["phase"] == "assess-workers":
                return {
                    "action": "final", "revision_requests": [],
                    "critic_objective": "Blindly verify every candidate.",
                }
            if task["phase"] == "finalize":
                return {
                    "action": "final",
                    "accepted_finding_indices": list(
                        range(len(task["candidate_findings"]))
                    ),
                    "confidence_adjustments": [],
                }
            raise AssertionError(task["phase"])
        if role == "correctness-reliability":
            instructions = "\n".join(
                item.get("instructions", "")
                for item in task.get("active_agent_skills") or []
            )
            rendered_diff = json.dumps(task.get("diff"), ensure_ascii=False)
            if "TODO" in instructions and "TODO" in rendered_diff:
                return {"action": "final", "findings": [{
                    "rule_id": "QUALITY-UNFINISHED", "severity": "low",
                    "title": "Unfinished production behavior",
                    "explanation": "The added TODO marks unfinished production behavior.",
                    "path": "a.py", "line": 2,
                    "evidence": "# TODO finish validation",
                    "fix": "Complete the behavior before merge.",
                    "test": "Add a regression test for the unfinished path.",
                    "confidence": 0.8,
                }]}
            return {"action": "final", "findings": []}
        if role == "security":
            return {"action": "final", "findings": []}
        if role == "critic":
            return {
                "action": "final",
                "decisions": [
                    {
                        "finding_index": index,
                        "accepted": True,
                        "objections": [],
                        "confidence_adjustment": 0.0,
                    }
                    for index, _item in enumerate(task["candidates"])
                ],
            }
        raise AssertionError(role)


# 将服务切换到确定性模型替身，使测试运行完整协作链路而无需外部请求。
def enable_agentic_service(service):
    service.chat_client = FakeAgenticClient()
    service.reviewer = service._build_agentic_reviewer()
    service.harness.reviewer = service.reviewer
    return service
